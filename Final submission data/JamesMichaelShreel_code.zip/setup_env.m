% Setup the environment
addpath(genpath('./train/'))
addpath(genpath('./test/'))
addpath(genpath('./NIFTI_20110921/'))
addpath(genpath('./starter_code/'))